from tuner import SRO_Data, Alloy, Quaternary, Ternary
from checker import SRO