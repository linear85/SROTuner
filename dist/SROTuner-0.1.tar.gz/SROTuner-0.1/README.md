Two main functions:
	1. check the Warren-Cowley parameters of given sample
	2. Tune the atomic configuration to given Warren-Cowley parameters 

It works for FCC and BCC crystal structures.
It can not work for any other crystal structure.